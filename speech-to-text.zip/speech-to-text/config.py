path_to_recordings_ = "/home/nandni_yadav/speech-to-text/recordings"
path_to_archive_ = "/home/nandni_yadav/speech-to-text/archive/"
path_to_output_ = "/home/nandni_yadav/speech-to-text/output/"

